"""
These procedures are various misc stubs useful in analysis
"""
