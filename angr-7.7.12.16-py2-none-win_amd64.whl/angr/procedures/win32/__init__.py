"""
These procedures implement functions from the win32 api, notably kernel32.dll
"""
