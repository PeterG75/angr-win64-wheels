from .fputc import fputc as putc
