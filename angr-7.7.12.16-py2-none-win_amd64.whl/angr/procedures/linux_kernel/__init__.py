"""
These procedures implement linux system calls or other misc functionality provided by the linux kernel
"""
