"""
These function implement functions or other functionalities provided by the linux userspace dynamic loader
"""
