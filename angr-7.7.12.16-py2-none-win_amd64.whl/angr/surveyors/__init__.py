all_surveyors = { }

from .surveyor import Surveyor, Surveyors
from .explorer import Explorer
from .executor import Executor
from .escaper import Escaper
from .slicecutor import Slicecutor, HappyGraph
from .caller import Caller
