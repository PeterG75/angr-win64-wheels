class PyVEXError(Exception):
    pass
