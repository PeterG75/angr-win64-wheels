print '... Importing simuvex/engines/vex/statements/wrtmp.py ...'
from angr.engines.vex.statements.wrtmp import *
