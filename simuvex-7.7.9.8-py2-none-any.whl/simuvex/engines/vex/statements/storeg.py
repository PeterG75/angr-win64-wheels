print '... Importing simuvex/engines/vex/statements/storeg.py ...'
from angr.engines.vex.statements.storeg import *
