print '... Importing simuvex/plugins/scratch.py ...'
from angr.state_plugins.scratch import *
