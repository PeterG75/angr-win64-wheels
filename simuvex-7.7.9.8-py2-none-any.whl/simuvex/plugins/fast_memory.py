print '... Importing simuvex/plugins/fast_memory.py ...'
from angr.state_plugins.fast_memory import *
