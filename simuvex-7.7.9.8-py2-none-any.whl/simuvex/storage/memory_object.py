print '... Importing simuvex/storage/memory_object.py ...'
from angr.storage.memory_object import *
