print '... Importing simuvex/s_format.py ...'
from angr.procedures.stubs.format_parser import *
