print '... Importing simuvex/s_slicer.py ...'
from angr.slicer import *
