print '... Importing simuvex/s_cc.py ...'
from angr.calling_conventions import *
