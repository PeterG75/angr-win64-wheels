print '... Importing simuvex/s_action_object.py ...'
from angr.state_plugins.sim_action_object import *
